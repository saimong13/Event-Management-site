<?php
session_start();
include("db_connect.php");

// Check if user is logged in
if (!isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit();
}

$user_email = $_SESSION['user_email'];

// Fetch bookings using email
$bookings = mysqli_query($conn, "SELECT event_name, event_date, tickets, price 
                                 FROM bookings 
                                 WHERE email='$user_email'");

// Optional: If you later create a registrations table, you can re-enable this
// $registrations = mysqli_query($conn, "SELECT e.title, r.status 
//                                       FROM registrations r 
//                                       JOIN events e ON r.event_id = e.id 
//                                       WHERE r.email='$user_email'");
?>

<!DOCTYPE html>
<html>
<head>
  <title>User Dashboard</title>
  <link rel="stylesheet" href="style.css">
  <style>
  body {
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(to right, #f0f4f8, #d9e2ec);
    margin: 0;
    padding: 0;
  }

  .container {
    max-width: 800px;
    margin: 40px auto;
    background: #fff;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 0 20px rgba(0,0,0,0.1);
  }

  h2 {
    text-align: center;
    color: #2c3e50;
    margin-bottom: 30px;
  }

  section {
    margin-bottom: 40px;
  }

  h3 {
    color: #34495e;
    border-bottom: 2px solid #eee;
    padding-bottom: 10px;
    margin-bottom: 20px;
  }

  ul {
    list-style: none;
    padding: 0;
  }

  li {
    background: #f9f9f9;
    margin-bottom: 10px;
    padding: 15px;
    border-left: 5px solid #3498db;
    border-radius: 6px;
    font-size: 16px;
    color: #333;
  }

  a {
    display: inline-block;
    margin-top: 10px;
    color: #3498db;
    text-decoration: none;
    font-weight: bold;
  }

  a:hover {
    text-decoration: underline;
  }

  .logout {
    text-align: center;
    margin-top: 20px;
  }
</style>
</head>
<body>
  <h2>Welcome to Your Dashboard</h2>
  <section>
    <h3>📅 My Bookings</h3>
    <ul>
      <?php while($row = mysqli_fetch_assoc($bookings)){ ?>
        <li>
          <?php echo $row['event_name']." - ".$row['event_date']." | Tickets: ".$row['tickets']." | Price: ".$row['price']; ?>
        </li>
      <?php } ?>
    </ul>
  </section>

  <section>
    <h3>🔍 Explore Events</h3>
    <a href="explore event.html">Go to Explore Page</a>
  </section>

  <p><a href="logout.php">Logout</a></p>
</body>
</html>
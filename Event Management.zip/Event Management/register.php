<?php
session_start();
include("db_connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $email = isset($_POST['email']) ? strtolower(trim($_POST['email'])) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    // Hash password securely
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Check if email already exists
    $check = mysqli_query($conn, "SELECT id FROM users WHERE email='$email'");
    if (mysqli_num_rows($check) > 0) {
        echo "⚠️ Email already registered. Please <a href='login.php'>login</a>.";
    } else {
        $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$hashed_password')";
        if (mysqli_query($conn, $sql)) {
            echo "✅ Registration successful! <a href='login.php'>Login here</a>";
        } else {
            echo "❌ Error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Register</title></head>
<style>
    body {
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', Arial, sans-serif;
      background: url(11122242-180846090.jpg) no-repeat center center fixed;
      background-size: cover;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    form {
      width: 320px;
      padding: 30px;
      background: rgba(255, 255, 255, 0.15);
      border-radius: 12px;
      backdrop-filter: blur(10px);
      box-shadow: 0 8px 20px rgba(0,0,0,0.3);
      text-align: center;
    }

    form input[type="text"],
    form input[type="email"],
    form input[type="password"] {
      width: 100%;
      padding: 12px;
      margin: 10px 0;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      background: rgba(255,255,255,0.8);
      color: #333;
    }

    form button {
      width: 100%;
      padding: 12px;
      background-color: #ff6f00;
      border: none;
      border-radius: 6px;
      color: white;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      transition: background 0.3s;
    }

    form button:hover {
      background-color: #e65c00;
    }

    form p {
      margin-top: 15px;
      font-size: 14px;
      color: black;
    }

    form a {
      color: black;
      text-decoration: underline;
      font-size: 15px;
    }

    /* Social Sign-Up Section */
    .divider {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      color: black;
      font-size: 15px;
      margin: 20px 0 10px;
    }

    .divider hr {
      flex: 1;
      border: none;
      border-top: 1px solid black;
      font-size: 15px;
    }

    .social-buttons {
      display: flex;
      justify-content: center;
      gap: 10px;
      margin-top: 10px;
    }

    .social-btn {
      display: flex;
      align-items: center;
      gap: 6px;
      border: 1px solid teal;
      background: #fff;
      color: teal;
      padding: 8px 12px;
      border-radius: 5px;
      font-weight: bold;
      font-size: 0.9rem;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    .social-btn img {
      width: 18px;
      height: 18px;
    }

    .social-btn:hover {
      background: teal;
      color: #fff;
    }
  </style>
<body>
  <form action="" method="POST">
    <script src="register.js"></script>
    <input type="text" name="username" placeholder="Username" required />
    <input type="email" name="email" class="input-box" placeholder="Email" required />
    <input type="password" name="password" placeholder="Password" required />
    <button type="submit">Register</button>
    <p>Already have an account? <a href="login.html">Login here</a></p>

    <!-- Social Sign-Up Section -->
    <div class="divider">
      <hr><span>or sign up with</span><hr>
    </div>
    <div class="social-buttons">
      <button type="button" class="social-btn">
        <img src="https://pngimg.com/uploads/google/google_PNG19635.png" alt="Google" />
        Google
      </button>
      <button type="button" class="social-btn">
        <img src="https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg" alt="Apple" />
        Apple
      </button>
      <button type="button" class="social-btn">
        <img src="https://upload.wikimedia.org/wikipedia/commons/c/ca/LinkedIn_logo_initials.png" alt="LinkedIn" />
        LinkedIn
      </button>
    </div>
  </form>
</body>
</html>
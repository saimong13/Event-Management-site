<?php
session_start(); // start session to check login
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SaiEvent | Home</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: Arial, sans-serif; line-height: 1.6; }

    /* Navigation Bar */
    nav {
      background: #21a3aeff;
      color: #fff;
      padding: 1rem 2rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: fixed;
      width: 100%;
      top: 0;
      z-index: 1000;
    }
    nav .logo { font-size: 1.5rem; font-weight: bold; }
    nav ul { list-style: none; display: flex; align-items: center; }
    nav ul li { margin-left: 20px; }
    nav ul li a { color: #fff; text-decoration: none; transition: color 0.3s ease; }
    nav ul li a:hover { color: #f39c12; }

    /* Account Icon */
    .account-icon {
      width: 35px; height: 35px;
      border-radius: 50%;
      background-color: #555;
      display: flex; justify-content: center; align-items: center;
      cursor: pointer; font-size: 18px;
    }

    /* Account Section */
    .account-section {
      display: none;
      position: absolute;
      right: 20px; top: 70px;
      background: #fff; color: #333;
      padding: 15px; border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
      width: 220px;
    }
    .account-section h3 { margin-top: 0; }
    .account-section p { margin: 5px 0; }

    /* Hero Banner */
    .hero {
      height: 100vh;
      background: url(11122242-180846090.jpg) no-repeat center center/cover;
      display: flex; justify-content: center; align-items: center;
      text-align: center; color: #fff; padding: 0 20px;
    }
    .hero h1 { font-size: 3rem; margin-bottom: 20px; text-shadow: 2px 2px 5px rgba(0,0,0,0.7); }
    .hero p { font-size: 1.2rem; margin-bottom: 30px; text-shadow: 1px 1px 3px rgba(0,0,0,0.7); }
    .hero a {
      background: #f39c12; color: #fff;
      padding: 12px 25px; text-decoration: none;
      font-size: 1rem; border-radius: 5px;
      transition: background 0.3s ease;
    }
    .hero a:hover { background: #d35400; }
  </style>
</head>
<body>
  <!-- Navigation -->
  <nav>
    <div class="logo">saiEvent</div>
    <ul>
      <li><a href="events.html">Events</a></li>
      <li><a href="about.html">About</a></li>
      <li><a href="contact.html">Contact</a></li>

    </ul>
  </nav>

  <!-- Account Section -->
  <?php if(isset($_SESSION['user_name'])): ?>
    <div class="account-section" id="accountSection">
      <h3>User Account</h3>
      <p><strong>Name:</strong> <?php echo $_SESSION['user_name']; ?></p>
      <p><strong>Email:</strong> <?php echo $_SESSION['user_email']; ?></p>
      <form method="post" action="logout.php">
        <button type="submit">Logout</button>
      </form>
    </div>
  <?php endif; ?>

  <!-- Hero Banner -->
  <section class="hero">
    <div>
      <h1>Welcome to saiEvent</h1>
      <p>Your one-stop solution for managing and attending amazing events.</p>
      <a href="explore event.html">Explore Events</a>
    </div>
  </section>

  <script>
    function toggleAccount() {
      const section = document.getElementById("accountSection");
      section.style.display = section.style.display === "block" ? "none" : "block";
    }
  </script>
</body>
</html>
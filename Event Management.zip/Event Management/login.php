<?php
session_start();
include("db_connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = isset($_POST['email']) ? strtolower(trim($_POST['email'])) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    $result = mysqli_query($conn, "SELECT id, password FROM users WHERE email='$email'");
    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);

        // Verify password
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];       // store user ID
            $_SESSION['user_email'] = $email;        // store user email
            header("Location: dashboard.php");
            exit();
        } else {
            echo "❌ Incorrect password.";
        }
    } else {
        echo "❌ Email not found.";
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Login</title>
<style>
        body {
  margin: 0;
  padding: 0;
  font-family: 'Segoe UI', Arial, sans-serif;
  background: url(11122242-180846090.jpg) no-repeat center center fixed; /* optional background */
  background-size: cover;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

form {
  width: 320px;
  padding: 30px;
  background: rgba(255, 255, 255, 0.15); /* transparent white */
  border-radius: 12px;
  backdrop-filter: blur(10px); /* frosted glass effect */
  box-shadow: 0 8px 20px rgba(0,0,0,0.3);
  text-align: center;
}

form input[type="email"],
form input[type="password"] {
  width: 100%;
  padding: 12px;
  margin: 10px 0;
  border: none;
  border-radius: 6px;
  font-size: 16px;
  background: rgba(255,255,255,0.8);
  color: #333;
}

form button {
  width: 100%;
  padding: 12px;
  background-color: #ff6f00;
  border: none;
  border-radius: 6px;
  color: white;
  font-size: 16px;
  font-weight: bold;
  cursor: pointer;
  transition: background 0.3s;
}

form button:hover {
  background-color: #e65c00;
}

form p {
  margin-top: 15px;
  font-size: 14px;
  color: #fff;
}

form a {
  color:black;
  text-decoration: underline;
}
    </style>
</head>
<body>

<form action="login.php" method="POST">
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Login</button>
    <a href="register.php">Create an account</a>
</form>

</body>
</html>

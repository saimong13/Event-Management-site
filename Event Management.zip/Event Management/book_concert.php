<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$servername = "localhost";
$username   = "root";       // change if needed
$password   = "";           // change if needed
$dbname     = "saievent";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get form data safely
$name    = isset($_POST['name']) ? $_POST['name'] : '';
$email   = isset($_POST['email']) ? $_POST['email'] : '';
$tickets = isset($_POST['tickets']) ? (int)$_POST['tickets'] : 0;
$price   = isset($_POST['price']) ? (float)$_POST['price'] : 0; // price per ticket

// Event details (hardcoded for now)
$event_name = "Live Music Night";
$event_date = "2025-12-20";

// Calculate total
$total_cost = $tickets * $price;

// Insert booking
$sql = "INSERT INTO bookings (name, email, tickets, event_name, event_date, price)
        VALUES ('$name', '$email', '$tickets', '$event_name', '$event_date', '$price')";

if ($conn->query($sql) === TRUE) {
  // Show receipt
  echo "<div style='font-family:Arial; max-width:600px; margin:40px auto; padding:20px; border:1px solid #ccc; border-radius:8px;'>";
  echo "<h2 style='color:#ff4081;'>Booking Receipt</h2>";
  echo "<p><strong>Name:</strong> $name</p>";
  echo "<p><strong>Email:</strong> $email</p>";
  echo "<p><strong>Event:</strong> $event_name</p>";
  echo "<p><strong>Date:</strong> $event_date</p>";
  echo "<p><strong>Tickets:</strong> $tickets</p>";
  echo "<p><strong>Price per Ticket:</strong> $price BDT</p>";
  echo "<p><strong>Total Cost:</strong> $total_cost BDT</p>";
  echo "<hr>";
  echo "<p>Thank you for booking! Please keep this receipt for entry.</p>";
  echo "</div>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
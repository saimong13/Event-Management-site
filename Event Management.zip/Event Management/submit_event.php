<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Collect form data
  $eventType = $_POST['event_type'] ?? '';
  $theme = $_POST['theme'] ?? '';
  $extras = isset($_POST['extras']) ? implode(", ", $_POST['extras']) : 'None';
  $budget = $_POST['budget'] ?? 0;

  // Additional fields for event_bookings
  $venue = "Dhaka Convention Center"; // You can make this dynamic later
  $eventDate = date("Y-m-d", strtotime("+30 days")); // Example: 30 days from now
  $status = "Pending";

  // Connect to MySQL
  $conn = new mysqli("localhost", "root", "", "saievent");
  if ($conn->connect_error) {
    die("<h3 style='color:red;'>❌ Connection failed: " . $conn->connect_error . "</h3>");
  }

  // Insert into bookings table
  $stmt1 = $conn->prepare("INSERT INTO event_bookings (event_type, theme, extras, budget) VALUES (?, ?, ?, ?)");
  if (!$stmt1) {
    die("<h3 style='color:red;'>❌ Error preparing bookings query: " . $conn->error . "</h3>");
  }
  $stmt1->bind_param("sssi", $eventType, $theme, $extras, $budget);
  $stmt1->execute();
  $bookingId = $stmt1->insert_id;
  $stmt1->close();

  // Insert into event_bookings table
  $stmt2 = $conn->prepare("INSERT INTO event_reservations (booking_id, venue, event_date, status) VALUES (?, ?, ?, ?)");
  if (!$stmt2) {
    die("<h3 style='color:red;'>❌ Error preparing event_bookings query: " . $conn->error . "</h3>");
  }
  $stmt2->bind_param("isss", $bookingId, $venue, $eventDate, $status);
  $stmt2->execute();
  $stmt2->close();

  $conn->close();

  // Success message
  echo "<div style='padding:20px; background:#e0ffe0; border:1px solid #0a0; border-radius:8px; font-family:Segoe UI;'>
          <h2 style='color:green;'>✅ Booking Confirmed!</h2>
          <p>Your event has been scheduled at <strong>$venue</strong> on <strong>$eventDate</strong>.</p>
          <p>Status: <strong>$status</strong></p>
        </div>";
}
?>
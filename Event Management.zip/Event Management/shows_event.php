<?php
// Connect to DB
$conn = new mysqli("localhost", "root", "", "event_db");
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Fetch bookings
$sql = "SELECT * FROM bookings ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Submitted Events</title>
  <style>
    table {
      border-collapse: collapse;
      width: 80%;
      margin: 20px auto;
    }
    th, td {
      border: 1px solid #ccc;
      padding: 10px;
      text-align: center;
    }
    th {
      background: teal;
      color: white;
    }
  </style>
</head>
<body>
  <h2 style="text-align:center;">📋 Submitted Events</h2>
  <table>
    <tr>
      <th>ID</th>
      <th>Event Type</th>
      <th>Theme</th>
      <th>Extras</th>
      <th>Budget</th>
      <th>Created At</th>
    </tr>
    <?php
    if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>".$row['id']."</td>
                <td>".$row['event_type']."</td>
                <td>".$row['theme']."</td>
                <td>".$row['extras']."</td>
                <td>".$row['budget']."</td>
                <td>".$row['created_at']."</td>
              </tr>";
      }
    } else {
      echo "<tr><td colspan='6'>No events found</td></tr>";
    }
    ?>
  </table>
</body>
</html>